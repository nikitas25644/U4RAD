# E-Commerce
I designed and developed my first web application and user interfaces. This project is based upon E-commerce with multiple pages. I worked with Python [DJANGO], Html5, BOOTSTRAP for designing front-end and event handling. SQLITE For Database.
